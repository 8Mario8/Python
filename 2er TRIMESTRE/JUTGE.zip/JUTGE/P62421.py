lista_palabras = input().split()
lista_invertida = list(reversed(lista_palabras))
lista_invertida = " ".join(lista_invertida)
print(lista_invertida)