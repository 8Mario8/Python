numeros = input().split()
d = int(numeros[0]) // int(numeros[1])
r = int(numeros[0]) % int(numeros[1])
print(d, r)