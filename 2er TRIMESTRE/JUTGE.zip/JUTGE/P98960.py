letra = input()
if letra.islower():
    print(letra.upper())
else:
    print(letra.lower())