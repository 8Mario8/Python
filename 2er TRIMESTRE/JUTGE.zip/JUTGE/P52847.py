numeros = input().split()
numeros = [int(numero) for numero in numeros]
maximo = max(numeros)
print(maximo)