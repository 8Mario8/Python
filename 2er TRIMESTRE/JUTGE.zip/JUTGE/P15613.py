temperatura = int(input())
if temperatura < 10:
    print("fa fred")
elif temperatura > 30:
    print("fa calor")
else:
    print("s'esta be")
if temperatura <= 0:
    print("l'aigua es gelaria")
elif temperatura >= 100:
    print("l'aigua bulliria")