#3. Programa que pida dos números enteros y realice la suma correspondiente
var1=int(input("Introduce un número: "))
var2=int(input("Introduce otro número: "))
total=var1+var2
print("El resultado de la suma es: ", total)