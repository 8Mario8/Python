#2. Programa que introduzca por teclado tres tipos de variables y se muestren por pantalla en el siguiente orden: número entero, texto y número decimal.
var1=int(input("Introduce un número: "))
var2=input("Introduce una letra: ")
var3=float(input("Introduce un número decimal: "))
print("El valor introducido es el número:", var1)
print("El valor introducido es la letra:", var2)
print("El valor introducido es el número decimal", var3)