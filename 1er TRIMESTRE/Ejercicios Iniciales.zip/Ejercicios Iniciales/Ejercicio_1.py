#1. Programa que muestre por pantalla la frase "Hello World".
print("Hello World")