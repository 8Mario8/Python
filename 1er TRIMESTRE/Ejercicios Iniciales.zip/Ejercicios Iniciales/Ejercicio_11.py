#11. Realiza un programa que introduciendo el valor del lado de un cuadrado nos devuelva por pantalla en el área y el perímetro.
var1=float(input("Introduce la longitud del lado del cuadrado: "))
perímetro=var1+var1+var1+var1
área=var1*var1
print("El perímetro de cuadrado es: ", perímetro)
print("El área de cuadrado es: ", área)