#8. Programa que pida un número de horas y muestre por pantalla los minutos y segundos
horas = float(input("Introduce el número de horas: "))
minutos = horas*60
segundos = horas*3600
print( horas, "horas son equivalentes a", minutos, "minutos o", segundos, "segundos.")