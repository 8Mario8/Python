#29. Busca Internet qué función permite obtener la longitud de un String, realiza un programa que al introducir una frase devuelva la longitud
frase=input("Introduce una frase: ")
print("La longitud de la frase es de", len(frase), "caracteres.")