#50. Realiza un programa que de los buenos días 3 veces. Con While
rep=0
while rep<3:
    print("Buenos días")
    rep=rep+1